// Simple AI chat logic for Bloombox demo
const BLOOMBOX_WELCOME = "Hi! I'm Bloombox, your friendly AI. How can I help you today?";

function addMessage(text, sender) {
    const chatHistory = document.getElementById('bloombox-chat-history');
    const msgDiv = document.createElement('div');
    msgDiv.className = sender === 'user' ? 'bloombox-msg user' : 'bloombox-msg ai';
    msgDiv.textContent = text;
    chatHistory.appendChild(msgDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

async function aiResponse(userMsg) {
    // Show loading indicator
    addMessage('...', 'ai');
    try {
        const response = await fetch('/bloombox-chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: userMsg })
        });
        const data = await response.json();
        return data.reply || "Sorry, I couldn't process that.";
    } catch (err) {
        return "Sorry, I'm having trouble connecting to AI right now.";
    }
}

document.addEventListener('DOMContentLoaded', function() {
    addMessage(BLOOMBOX_WELCOME, 'ai');
    const form = document.getElementById('bloombox-form');
    const input = document.getElementById('bloombox-input');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const userMsg = input.value.trim();
        if (!userMsg) return;
        addMessage(userMsg, 'user');
        aiResponse(userMsg).then(reply => {
            // Remove loading indicator (last AI message is ...)
            const chatHistory = document.getElementById('bloombox-chat-history');
            const lastMsg = chatHistory.lastChild;
            if (lastMsg && lastMsg.classList.contains('ai') && lastMsg.textContent === '...') {
                chatHistory.removeChild(lastMsg);
            }
            addMessage(reply, 'ai');
        });
        input.value = '';
    });
});
